WREN MATNEW | FOUNDATION ARCHIVE

DESIGN: Original Foundation dark-teal interface with themed departmental sections.

PUBLISH: Create a GitHub repository. Upload index.html and records.json from this folder to the repository root. In Settings > Pages, choose Deploy from a branch, main, root. Wait for deployment.

UPDATE RECORDS: In the repository, open records.json and click the pencil (Edit). Edit the body, title, status, or existing records in JSON; commit. The site will load the updated records on every visit. Keep valid JSON formatting. For substantial changes, edit a local copy and upload the replacement records.json.

The website is read-only for visitors. GitHub repository write permissions control who can make changes to the published records. Do not put secrets in records.json.

LOCAL PREVIEW: Open index.html directly. The embedded fallback records are visible offline. Once hosted, records.json is loaded instead, so updates are immediate.

